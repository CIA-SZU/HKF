function [Population,z,znad] = EnvironmentalSelection(Population,K,z,Lp)
  %% Non-dominated sorting
  [FrontNo,MaxFNo] = NDSort(Population.objs,K);
  St = FrontNo<=MaxFNo;
   Population=Population(St);
   PopObj =Population.objs ;
   [N,M]  = size(PopObj);
    R     = 1 : N;         % Set of remaining solutions
    Rp   = [];            % Set of privileged solutions
    z = min(PopObj,[],1);
    PopObj = PopObj - repmat(z,N,1); 
   %% Select the corner solutions
   [R,Rp,znad]=SelectCornerSolutions(PopObj,N,M,R,Rp);
   %% Normalization
   PopObj = PopObj./repmat(znad,size(PopObj,1),1);
   Con=Calculate_Convergence(PopObj);
   d=Calculate_Distribution(PopObj,Lp);
   
  while length(Rp)<K     
        APT_min=min(d(R,Rp),[],2);        
        [~,APT_Sort]=sort(APT_min,'descend'); 
        [~,Con_sort]=sort(Con(R));      
        Mean_APT=APT_min(APT_Sort(min(K-length(Rp),length(APT_Sort))));           
        index=find(APT_min(Con_sort)>=0.95*Mean_APT); 
        xunique=R(Con_sort(index(1)));
        Rp=[Rp,xunique];
        R(Con_sort(index(1))) = []; 
  end
     Population = Population(Rp);
end
function[R,Rp,znad]=SelectCornerSolutions(PopObj,N,M,R,Rp)
    W = zeros(M) + 1e-6;
    W(logical(eye(M))) = 1;
    selIndex = [] ;
    for i = 1:size(W,2)
        k = PopObj * W(:,i)./ norm(W(:,i));
        perpenVecs = PopObj -repmat(k,1,M).* repmat(W(:,i)',N,1);
        perpDist = sum(abs(perpenVecs).^2,2).^(1/2);
        [~,index] = min(perpDist);
        selIndex = [selIndex,index];
        znad(i)=PopObj(index,i)+10^-6;
    end
    xunique = R(selIndex);
     Rp = [Rp,xunique];
     R(xunique)    = [];
end
function [FC]=Calculate_Convergence(PopObj)      
     FC= sum(PopObj,2);
end
function [d]=Calculate_Distribution(PopObj,Lp)
     [~,M]=size(PopObj);
    PopObj=PopObj+10^-6;
     c =(sum(PopObj.^Lp,2)).^(1/Lp);
    tran_Obj=PopObj./repmat(c,1,M);  
     d = pdist2(tran_Obj,tran_Obj,'euclidean');
end

