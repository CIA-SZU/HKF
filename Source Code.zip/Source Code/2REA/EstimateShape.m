function p= EstimateShape(Population,N,z,znad)
% Estimate the  shape of PF
    %% Normalization
    [FrontNo,MaxFNo] = NDSort(Population.objs,N);
    St = FrontNo<=MaxFNo;
   Population=Population(St);
   PopObj =Population.objs ;
    PopObj = (PopObj- repmat(z,N,1))./repmat(znad,N,1);
    %candidate P value
    CP=0.5:0.1:2; 
    for i=1:length(CP)
        g = (sum(PopObj.^CP(i),2)).^(1/CP(i));
        Vp(i)=std(g);
    end  
    [~,index]=min(Vp);
    p=CP(index);
end