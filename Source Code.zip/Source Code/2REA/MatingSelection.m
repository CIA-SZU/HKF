function MatingPool = MatingSelection(PopObj,N,p,z,znad)
% The mating selection of 2REA
    PopObj = (PopObj- repmat(z,N,1))./repmat(znad,N,1);
    [d]=Calculate_Distribution(PopObj,p);
    D  = sort(d,2);
    dk = 1./(sum(D(:,2:ceil(end*0.1)),2)+1);
    MatingPool = TournamentSelection(2,N,dk);
end
function [d]=Calculate_Distribution(PopObj,p)
     [~,M]=size(PopObj);
     norm =(sum(PopObj.^p,2)).^(1/p);
    tran_Obj=PopObj./repmat(norm,1,M);
    d = pdist2(tran_Obj,tran_Obj,'euclidean');
end

