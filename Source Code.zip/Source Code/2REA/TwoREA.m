function TwoREA(Global)
% <algorithm> <A-G>
% A Many-Objective Evolutionary Algorithm Based On A Two-Round-Selection Strategy
    Population   = Global.Initialization();
    [z,znad]     = deal(min(Population.objs),max(Population.objs));
    %% Optimization
     while Global.NotTermination(Population)  
           Lp= EstimateShape(Population,Global.N,z,znad);
           MatingPool=MatingSelection(Population.objs,Global.N,Lp,z,znad);
           Offspring  = Global.Variation(Population(MatingPool));  
           [Population,z,znad] = EnvironmentalSelection([Population,Offspring],Global.N,z,Lp);
     end
end